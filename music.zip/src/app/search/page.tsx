import React from 'react'

export default function search() {
  return (
    <div>Search</div>
  )
}
