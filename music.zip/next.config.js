/** @type {import('next').NextConfig} */
const nextConfig = {
//   output: "standalone",
//   next: {
//     modifyConfig: false,
//   },
};

module.exports = nextConfig;
